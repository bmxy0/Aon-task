import Container from "../../components/Container/container";

const AboutScreen = () => {
  return (
    <div>
      <Container>About Screen</Container>
    </div>
  );
};

export default AboutScreen